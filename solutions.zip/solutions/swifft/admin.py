from django.contrib import admin
from .models import contactus


admin.site.register(contactus),
# Register your models here.
